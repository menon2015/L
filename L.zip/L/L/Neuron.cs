﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L
{
    internal class Neuron
    {
        double input;
        public double output;
        public double error;

        public Neuron(double input)
        {
            this.input = input;
        }

        public void calculate_output()
        {
            output = 1 / (1 + Math.Exp((-1)*input));
        }
    }
}
