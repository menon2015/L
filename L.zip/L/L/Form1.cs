﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L
{
    public partial class Form1 : Form
    {

        List<ONEPIECE> pieces = new List<ONEPIECE>();
        List<Network> networks = new List<Network>();
        int counter = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string s;
            StreamReader sr = new StreamReader("ONEPIECES.txt");

            while (!sr.EndOfStream)
            {
                s = sr.ReadLine();
                Debug.WriteLine(s);

                string[] numbers = s.Split(',');
                ONEPIECE piece = new ONEPIECE(numbers);
                pieces.Add(piece);
                networks.Add(new Network(100, numbers,int.Parse(numbers[0])));
            }
            sr.Close();

            

            pictureBox1.Invalidate();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            counter++;
            pictureBox1.Invalidate();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            counter--;
            pictureBox1.Invalidate();
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
           if (pieces.Count != 0)
            {
                pieces[counter].Draw(g);
                label1.Text = networks[counter].finalOutput.ToString();
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
