﻿using System;
using System.Drawing;

namespace L
{
    internal class ONEPIECE
    {
        int Digit;
        int[,] image = new int[28, 28];



        public ONEPIECE(string[] numbers)
        {
            this.Digit = Convert.ToInt16(numbers[0]);
            for (int i = 1; i < numbers.Length; i++)
            {
                int x = (i - 1) % 28;
                int y = (i - 1) / 28;

                image[x, y] = Convert.ToInt16(numbers[i]);

            }
        }

        public void Draw(Graphics g)
        {
            for (int i = 0; i <28; i++)
            {
                for(int j = 0; j <28; j++)
                {
                    SolidBrush brush = new SolidBrush(Color.FromArgb(image[i, j], image[i,j], image[i,j]));
                    g.FillRectangle(brush, 18*i, 18*j, 12, 12);
                }

            }
        }
    }
}
