﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace L
{
    internal class MLP
    {
        float[] inputs;
        int hiddenNeuronsLenght;
        float[,] hiddenNeuronWeights;
        int outputNeutronsLenght;
        float[,] outputNeuronWeights;

        public MLP(int inputsLenght, int hiddenLenght, int outputLenght)
        {
            inputs = new float[inputsLenght];
            hiddenNeuronsLenght = hiddenLenght;
            hiddenNeuronWeights = new float[inputsLenght,hiddenLenght];

            outputNeutronsLenght = outputLenght;
            outputNeuronWeights = new float[hiddenLenght,outputLenght];
        }



        public float[] ForewardProcess(float[] inputs)
        {
            float[] outputs = new float[outputNeutronsLenght]; 

            for(int i=0; i < hiddenNeuronsLenght; i++)
            {

            }
            return outputs;
        }


        
    }
}
