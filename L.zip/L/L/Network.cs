﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L
{
    internal class Network
    {
        List<Neuron> HiddenNeurons = new List<Neuron>();
        List<Neuron> OutputNeutrons = new List<Neuron>();
        int HiddenNeutronCount;
        List<double> inputs = new List<double>();
        List<double> hiddenInputs = new List<double>();
        double biggestOutput;
        public int finalOutput; 
        double NeuronInput;
        Random rnd = new Random();
        List<double> hiddenWeights = new List<double>();
        List<double> outputWeights = new List<double> ();
        int trueValue;

        public Network(int hiddenNeutronCount, string[] numbers, int trueValue)
        {
            this.trueValue = trueValue;
            HiddenNeutronCount = hiddenNeutronCount;
            for (int i = 0; i < numbers.Length; i++)
            {
                inputs.Add(Convert.ToDouble(numbers[i]) / 255);
            }
            for (int j = 0; j < HiddenNeutronCount; j++)
            {
                hiddenWeights.Add(rnd.Next(-100000, 100000) * 0.0002);
            }
            for (int k = 0; k < 10; k++)
            {
                outputWeights.Add(rnd.Next(-100000, 100000) * 0.0002);
            }
            Process();
            this.trueValue = trueValue;
        }


        public void Setup(List<double> NeuronInputs,int NeuronCount,List<Neuron> neurons, List<double> NeuronWeights)
        {
            for(int i = 0; i < NeuronCount; i++)
            {
                NeuronInput = 0;
                for(int j = 0; j < NeuronInputs.Count(); j++)
                {
                    NeuronInput += NeuronInputs[j]* NeuronWeights[i];
                }
                neurons.Add(new Neuron(NeuronInput));
            }
        }


        public void Process()
        {
            Setup(inputs,HiddenNeutronCount,HiddenNeurons,hiddenWeights);
            foreach(var neuron in HiddenNeurons)
            {
                neuron.calculate_output();
                hiddenInputs.Add(neuron.output);
            }
            Setup(hiddenInputs, 10, OutputNeutrons, outputWeights);

            biggestOutput = OutputNeutrons[0].output;
            for (int i = 0; i < 10; i++)
            {
                OutputNeutrons[i].calculate_output();
                if(OutputNeutrons[i].output > biggestOutput)
                {
                    biggestOutput = OutputNeutrons[i].output;
                    finalOutput = i;
                }
              

            }
            for (int j = 0; j < 10; j++)
            {
                if(j == trueValue)
                {
                    OutputNeutrons[j].error = 0 - OutputNeutrons[j].output;
                }
            }
        }
    }
}
